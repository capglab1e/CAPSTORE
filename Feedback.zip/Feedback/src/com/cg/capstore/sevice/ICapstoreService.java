package com.cg.capstore.sevice;

import com.cg.capstore.dto.Feedback;

public interface ICapstoreService {
	
	public void addFeedback(Feedback feed);
}
