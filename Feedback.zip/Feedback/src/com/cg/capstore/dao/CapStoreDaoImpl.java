package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Feedback;



@Repository
@Transactional
public class CapStoreDaoImpl implements ICapstoreDao {
	
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public void addFeedback(Feedback feed) {
		entitymanager.persist(feed);
		entitymanager.flush();
	}

}
