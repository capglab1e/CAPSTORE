package com.cg.capstore.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICapstoreDao;
import com.cg.capstore.dto.Feedback;

@Service
public class CapStoreServiceImpl implements ICapstoreService {
	
	@Autowired
	ICapstoreDao dao;

	@Override
	public void addFeedback(Feedback feed) {
		dao.addFeedback(feed);
	}

}
