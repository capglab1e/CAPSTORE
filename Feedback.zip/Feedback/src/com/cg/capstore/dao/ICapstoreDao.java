package com.cg.capstore.dao;

import com.cg.capstore.dto.Feedback;

public interface ICapstoreDao {
	public void addFeedback(Feedback feed);

}
